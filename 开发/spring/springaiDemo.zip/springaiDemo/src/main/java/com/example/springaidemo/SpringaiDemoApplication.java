package com.example.springaidemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringaiDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringaiDemoApplication.class, args);
    }

}
